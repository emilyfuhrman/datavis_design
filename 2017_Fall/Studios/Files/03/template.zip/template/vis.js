/* ------------------------------------------------------------------
 TEMPLATE
 -------------------------------------------------------------------- */

var w = window.innerWidth,
		h = window.innerHeight;

var my_svg = d3.select('#my_great_div').append('svg')
	.attr('width',w)
	.attr('height',h)
	;